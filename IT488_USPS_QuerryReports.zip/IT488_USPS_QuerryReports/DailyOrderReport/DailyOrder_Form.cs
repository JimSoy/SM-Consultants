﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DailyOrderReport
{
    public partial class DailyOrder_Form : Form
    {
        public DailyOrder_Form()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(local);Initial Catalog=IT488_USPS;Integrated Security=True");

        private void btn_Execute_Click(object sender, EventArgs e)
        {
            string q = txt_SqlScript.Text;
            SqlDataAdapter dt = new SqlDataAdapter(q, con);
            DataSet ds = new DataSet();
            dt.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
