﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExpCreditQuery
{
    public partial class ExpiredCreditQuery_Form : Form
    {
        public ExpiredCreditQuery_Form()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(local);Initial Catalog=IT488_USPS;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            string q = textBox1.Text;
            SqlDataAdapter dt2 = new SqlDataAdapter(q, con);
            DataSet ds = new DataSet();
            dt2.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }
    }
}
