﻿namespace QueryDashboard
{
    partial class QueryDashboard_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainPanel = new System.Windows.Forms.PictureBox();
            this.btn_ZeroRefills = new System.Windows.Forms.Button();
            this.btn_NewOrders = new System.Windows.Forms.Button();
            this.btn_NotShipped = new System.Windows.Forms.Button();
            this.btn_ExpiredCredit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.mainPanel)).BeginInit();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.mainPanel.Location = new System.Drawing.Point(299, 12);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(1530, 791);
            this.mainPanel.TabIndex = 0;
            this.mainPanel.TabStop = false;
            this.mainPanel.Click += new System.EventHandler(this.mainPanel_Click);
            // 
            // btn_ZeroRefills
            // 
            this.btn_ZeroRefills.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_ZeroRefills.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ZeroRefills.Location = new System.Drawing.Point(12, 12);
            this.btn_ZeroRefills.Name = "btn_ZeroRefills";
            this.btn_ZeroRefills.Size = new System.Drawing.Size(150, 75);
            this.btn_ZeroRefills.TabIndex = 1;
            this.btn_ZeroRefills.Text = "Zero Refills";
            this.btn_ZeroRefills.UseVisualStyleBackColor = false;
            this.btn_ZeroRefills.Click += new System.EventHandler(this.btn_ZeroRefills_Click);
            // 
            // btn_NewOrders
            // 
            this.btn_NewOrders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_NewOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewOrders.Location = new System.Drawing.Point(12, 93);
            this.btn_NewOrders.Name = "btn_NewOrders";
            this.btn_NewOrders.Size = new System.Drawing.Size(150, 75);
            this.btn_NewOrders.TabIndex = 2;
            this.btn_NewOrders.Text = "New Orders";
            this.btn_NewOrders.UseVisualStyleBackColor = false;
            this.btn_NewOrders.Click += new System.EventHandler(this.btn_NewOrders_Click);
            // 
            // btn_NotShipped
            // 
            this.btn_NotShipped.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_NotShipped.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NotShipped.Location = new System.Drawing.Point(12, 174);
            this.btn_NotShipped.Name = "btn_NotShipped";
            this.btn_NotShipped.Size = new System.Drawing.Size(150, 75);
            this.btn_NotShipped.TabIndex = 3;
            this.btn_NotShipped.Text = "Orders\r\nNot Shipped";
            this.btn_NotShipped.UseVisualStyleBackColor = false;
            this.btn_NotShipped.Click += new System.EventHandler(this.btn_NotShipped_Click);
            // 
            // btn_ExpiredCredit
            // 
            this.btn_ExpiredCredit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_ExpiredCredit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ExpiredCredit.Location = new System.Drawing.Point(12, 255);
            this.btn_ExpiredCredit.Name = "btn_ExpiredCredit";
            this.btn_ExpiredCredit.Size = new System.Drawing.Size(150, 75);
            this.btn_ExpiredCredit.TabIndex = 4;
            this.btn_ExpiredCredit.Text = "Expired\r\nCredit";
            this.btn_ExpiredCredit.UseVisualStyleBackColor = false;
            this.btn_ExpiredCredit.Click += new System.EventHandler(this.btn_ExpiredCredit_Click);
            // 
            // QueryDashboard_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1841, 815);
            this.Controls.Add(this.btn_ExpiredCredit);
            this.Controls.Add(this.btn_NotShipped);
            this.Controls.Add(this.btn_NewOrders);
            this.Controls.Add(this.btn_ZeroRefills);
            this.Controls.Add(this.mainPanel);
            this.Name = "QueryDashboard_Form";
            this.Text = "Query Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.QueryDashboard_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mainPanel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox mainPanel;
        private System.Windows.Forms.Button btn_ZeroRefills;
        private System.Windows.Forms.Button btn_NewOrders;
        private System.Windows.Forms.Button btn_NotShipped;
        private System.Windows.Forms.Button btn_ExpiredCredit;
    }
}

