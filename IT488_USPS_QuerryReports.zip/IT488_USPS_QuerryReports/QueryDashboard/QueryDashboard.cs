﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QueryDashboard
{
    public partial class QueryDashboard_Form : Form
    {
        public QueryDashboard_Form()
        {
            InitializeComponent();
        }

        private void QueryDashboard_Form_Load(object sender, EventArgs e)
        {

        }

        public void loadform(Object Form)
        {
            if (this.mainPanel.Controls.Count > 0)
                this.mainPanel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainPanel.Controls.Add(f);
            this.mainPanel.Tag = f;
            f.Show();
        }
        private void btn_ZeroRefills_Click(object sender, EventArgs e)
        {
            loadform(new ZeroRefills_Form());
        }

        private void btn_NewOrders_Click(object sender, EventArgs e)
        {
            loadform(new DailyOrders_Form());
        }

        private void btn_NotShipped_Click(object sender, EventArgs e)
        {
            loadform(new OrdersNotShipped_Form());
        }

        private void btn_ExpiredCredit_Click(object sender, EventArgs e)
        {
            loadform(new ExpriedCredit_Form());
        }

        private void mainPanel_Click(object sender, EventArgs e)
        {

        }
    }
}
