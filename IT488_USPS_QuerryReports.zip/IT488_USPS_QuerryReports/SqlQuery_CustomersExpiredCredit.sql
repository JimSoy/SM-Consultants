SELECT Customers_List.Customer_FirstName, Customers_List.Customer_LastName, Customers_List.Customer_Phone, Customers_Payment_Info.Customer_Credit_ExpDate

FROM Customers_List

 Left JOIN Customers_Payment_Info ON Customers_Payment_Info.Customer_ID = Customers_List.Customer_ID
 
WHERE Customers_Payment_Info.Customer_Credit_ExpDate <= CURRENT_TIMESTAMP
