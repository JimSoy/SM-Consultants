SELECT Purchase_Orders.Customer_ID, Purchase_Orders.PO_ShipDate, Customers_List.Customer_FirstName, Customers_List.Customer_LastName

FROM Customers_List

JOIN Purchase_Orders ON Purchase_Orders.Customer_ID = Customers_List.Customer_ID
 
WHERE Purchase_Orders.PO_ShipDate is NULL

