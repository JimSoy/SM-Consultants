SELECT Prescription_Item.Prescription_Refill, Prescription_Item.Prescription_Name, Customers_List.Customer_FirstName, Customers_List.Customer_LastName, Doctor_List.Doctor_LastName, Doctor_List.Doctor_Phone

FROM Customers_List

 Right JOIN Prescription_Item ON Customers_List.Customer_ID = Prescription_Item.Customer_ID
 Right Join Doctor_List ON Customers_List.Customer_ID = Doctor_List.Customer_ID

WHERE Prescription_Item.Prescription_Refill = 0
