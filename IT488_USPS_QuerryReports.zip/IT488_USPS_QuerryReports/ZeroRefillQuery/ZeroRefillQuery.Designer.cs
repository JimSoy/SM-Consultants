﻿namespace ZeroRefillQuery
{
    partial class ZeroRefills_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ZeroRefills_Form));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_Execute = new System.Windows.Forms.Button();
            this.txt_SQLScript1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 249);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1749, 484);
            this.dataGridView1.TabIndex = 0;
            // 
            // btn_Execute
            // 
            this.btn_Execute.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Execute.Location = new System.Drawing.Point(826, 193);
            this.btn_Execute.Name = "btn_Execute";
            this.btn_Execute.Size = new System.Drawing.Size(125, 50);
            this.btn_Execute.TabIndex = 1;
            this.btn_Execute.Text = "Execute";
            this.btn_Execute.UseVisualStyleBackColor = false;
            this.btn_Execute.Click += new System.EventHandler(this.btn_Execute_Click);
            // 
            // txt_SQLScript1
            // 
            this.txt_SQLScript1.Location = new System.Drawing.Point(12, 12);
            this.txt_SQLScript1.Multiline = true;
            this.txt_SQLScript1.Name = "txt_SQLScript1";
            this.txt_SQLScript1.Size = new System.Drawing.Size(1749, 175);
            this.txt_SQLScript1.TabIndex = 2;
            this.txt_SQLScript1.Text = resources.GetString("txt_SQLScript1.Text");
            // 
            // ZeroRefills_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1773, 745);
            this.Controls.Add(this.txt_SQLScript1);
            this.Controls.Add(this.btn_Execute);
            this.Controls.Add(this.dataGridView1);
            this.Name = "ZeroRefills_Form";
            this.Text = "Zero Refills";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_Execute;
        private System.Windows.Forms.TextBox txt_SQLScript1;
    }
}

