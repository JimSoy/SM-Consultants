﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZeroRefillQuery
{
    public partial class ZeroRefills_Form : Form
    {
        public ZeroRefills_Form()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(local);Initial Catalog=IT488_USPS;Integrated Security=True");

        private void btn_Execute_Click(object sender, EventArgs e)
        {
            string q = txt_SQLScript1.Text;
            SqlDataAdapter dt = new SqlDataAdapter(q, con);
            DataSet ds = new DataSet();
            dt.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
